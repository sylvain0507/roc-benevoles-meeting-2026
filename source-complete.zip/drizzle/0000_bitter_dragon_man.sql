CREATE TABLE `assignments` (
	`id` text PRIMARY KEY NOT NULL,
	`volunteer_id` text NOT NULL,
	`slot_id` text NOT NULL,
	`period` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	FOREIGN KEY (`volunteer_id`) REFERENCES `volunteers`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `one_post_per_period` ON `assignments` (`volunteer_id`,`period`);--> statement-breakpoint
CREATE INDEX `assignments_slot` ON `assignments` (`slot_id`);--> statement-breakpoint
CREATE TABLE `request_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `post_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`minimum` integer,
	`ideal` integer,
	`closed` integer DEFAULT 0 NOT NULL,
	`note` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE `tasks` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`owner` text DEFAULT '' NOT NULL,
	`deadline` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'À faire' NOT NULL,
	`detail` text DEFAULT '' NOT NULL,
	`contact` text DEFAULT '' NOT NULL,
	`priority` text DEFAULT 'Normale' NOT NULL,
	`notes` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE `volunteers` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`first_name` text NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`email` text NOT NULL,
	`pin_hash` text NOT NULL,
	`identity` text NOT NULL,
	`official` integer DEFAULT 0 NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`manual` integer DEFAULT 0 NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `unique_volunteer_identity` ON `volunteers` (`identity`);--> statement-breakpoint
CREATE UNIQUE INDEX `unique_email_pin` ON `volunteers` (`email`,`pin_hash`);