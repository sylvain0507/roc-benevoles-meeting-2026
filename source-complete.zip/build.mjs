import fs from 'node:fs/promises';
const posts=JSON.parse(await fs.readFile('posts.json','utf8')),assets={},mime={html:'text/html; charset=utf-8',css:'text/css; charset=utf-8',js:'text/javascript; charset=utf-8',png:'image/png',svg:'image/svg+xml'};
for(const name of await fs.readdir('public'))assets['/'+name]={body:(await fs.readFile('public/'+name)).toString('base64'),type:mime[name.split('.').pop()]||'application/octet-stream'};
await fs.mkdir('dist/server',{recursive:true});await fs.mkdir('dist/.openai',{recursive:true});
await fs.writeFile('dist/server/index.js',`const POSTS=${JSON.stringify(posts)};\nconst ASSETS=${JSON.stringify(assets)};\n`+await fs.readFile('worker.js','utf8'));
await fs.copyFile('.openai/hosting.json','dist/.openai/hosting.json');console.log('Built ROC volunteers application');
